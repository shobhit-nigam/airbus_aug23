import music.effect.surround as sur

print(sur.s)

import music.effect.surround.s as lista

print(lista)
