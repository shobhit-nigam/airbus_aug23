from music.effect import *

print(voice.v)
print(theatre.t)
print(surround.s)
