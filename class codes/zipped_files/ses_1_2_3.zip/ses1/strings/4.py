# slice
# no out of bounds error 
name = "virat"

print(name[1:11])   
new_name = name[11:22]
print(len(new_name))

