dataA = "India wins"
dataB = "India's win"
dataC = 'India "wins"'
print(dataA)
print(dataB)
print(dataC)

#error
#dataD = "India wins'

