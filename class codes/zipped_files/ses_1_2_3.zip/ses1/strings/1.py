# indexing (negative)
name = "virat"
print(name[2])
print(name[-3])
