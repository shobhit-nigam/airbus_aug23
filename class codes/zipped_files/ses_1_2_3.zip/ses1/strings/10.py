dataA = "EX45yy100-7-ss"
dataB = "gyukjioa"
dataC = "2397"
dataD = "hello world"

# isalpha()
# isalnum()
# 
