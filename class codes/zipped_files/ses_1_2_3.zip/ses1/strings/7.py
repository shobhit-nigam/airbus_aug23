name = "virat"

print("name =", name)

print("name.upper =", name.upper())

print("name =", name)
