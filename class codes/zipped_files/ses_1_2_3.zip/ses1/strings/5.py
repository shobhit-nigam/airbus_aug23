name = "virat"

print(name)

name = "rohit"

print(name)

