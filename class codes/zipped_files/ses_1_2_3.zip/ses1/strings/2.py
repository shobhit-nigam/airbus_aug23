# indexing (negative)
name = "virat"
print(name[2])
print(name[-3])

# error
print(name[7])

print("last line code")

