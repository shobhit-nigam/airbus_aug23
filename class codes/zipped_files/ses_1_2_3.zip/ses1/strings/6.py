name = "virat"

print(name)

# error

name[-1] = "l"

print(name)
