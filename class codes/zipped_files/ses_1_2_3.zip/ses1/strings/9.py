name = "sachin ramesh tendulkar"

print(name.find("i"))
print(name.count("a"))
print(name.index("a"))
print(name.rindex("a"))

print(name.replace("a", "A"))
print(name)
