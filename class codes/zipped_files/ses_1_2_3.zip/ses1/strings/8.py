name = "sachin ramesh tendulkar"

print("name.title =", name.title())

print("name.capitalize =", name.capitalize())

print("name =", name)
