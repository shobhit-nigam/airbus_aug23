# slice
name = "virat"
print(name[2])
print(name[-3])

print(name[1:4])    #upper range not included 
print(name[0:3])
