avengers = ['ironman', 'thor', 'captain', 'hulk', 'thor', 'wanda', 'black widow']
marvel = ["woverine", "magneto", avengers]


print("marvel =", marvel)
print("marvel[2] =", marvel[2])
print("marvel[2][3] =", marvel[2][3])
print("marvel[2][3][1] =", marvel[2][3][1])
