avengers = ['ironman', 'thor', 'captain', 'hulk', 'thor', 'wanda', 'black widow']
marvel = ["woverine", "magneto"]
marvel.append(avengers)

print("marvel =", marvel)

#####################################
print("#"*15)
avengers = ['ironman', 'thor', 'captain', 'hulk', 'thor', 'wanda', 'black widow']
marvel = ["woverine", "magneto"]
marvel.extend(avengers)

print("marvel =", marvel)

empty = []
empty.append()
