avengers = ["ironman", "captain", "thor", "wanda"]
listNum = [23, 56, 8, 19, 43]

print(avengers)
print(avengers[1])
print(avengers[-1])
print(avengers[1:3])
