avengers = ["ironman", "captain", "thor", "wanda"]
listNum = [23, 56, 8, 19, 43]
