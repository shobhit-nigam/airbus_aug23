avengers = ['ironman', 'thor', 'captain', 'hulk', 'thor', 'wanda', 'black widow']
ave_new = avengers
heroes = avengers.copy()

print("avengers =", avengers)
print("ave_new =", ave_new)
print("heroes =", heroes)
avengers.sort()
avengers.remove("thor")
avengers.pop()
avengers.reverse()
print("avengers =", avengers)
print("ave_new =", ave_new)
print("heroes =", heroes)

"""demonstrating """
