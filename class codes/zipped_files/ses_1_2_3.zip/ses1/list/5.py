avengers = ["ironman", "captain", "thor", "wanda"]

print("avengers =", avengers)
avengers.append("black widow")
print("avengers =", avengers)
