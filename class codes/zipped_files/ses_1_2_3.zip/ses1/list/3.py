avengers = ["ironman", "captain", "thor", "wanda"]
listNum = [23, 56, 8, 19, 43, 65, 27, 95, 77]

print("listNum =", listNum)
print("listNum[:5] =", listNum[:5])
print("listNum[3:] =", listNum[3:])
print("listNum[:] =", listNum[:])

print("listNum[3::2] =", listNum[3::2])
