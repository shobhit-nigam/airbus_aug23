avengers = ["ironman", "captain", "thor", "wanda"]
listNum = [23, 56, 8, 19, 43, 65, 27, 95, 77]

print(avengers)
avengers[2] = "hulk"
print(avengers)
print("avengers[0] =", avengers[0])
print("avengers[0][4] =", avengers[0][4])
