avengers = ['ironman', 'thor', 'captain', 'hulk', 'thor', 'wanda', 'black widow']

#print("avengers =", avengers)
print(avengers.index("thor"))
#print("avengers =", avengers)
print(avengers.count("thor"))
