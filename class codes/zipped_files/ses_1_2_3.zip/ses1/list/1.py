avengers = ["ironman", "captain", "thor", "wanda"]
listNum = [23, 56, 8, 19, 43]

print(type(avengers))
print(type(listNum))
