avengers = ["ironman", "captain", "thor", "wanda"]

print("avengers =", avengers)
avengers.append("black widow")
print("avengers =", avengers)
avengers.insert(2, "hulk")
print("avengers =", avengers)
