avengers = ['ironman', 'captain', 'hulk', 'thor', 'wanda', 'black widow']

print("avengers =", avengers)
avengers.remove("thor")
print("avengers =", avengers)
avengers.pop(2)
print("avengers =", avengers)
avengers.pop()
print("avengers =", avengers)
avengers.clear()
print("avengers =", avengers)
