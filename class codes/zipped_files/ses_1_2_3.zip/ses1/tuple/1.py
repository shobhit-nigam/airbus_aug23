avengers = ['ironman', 'thor', 'captain', 'hulk', 'thor', 'wanda', 'black widow']
print("type of avengers =", type(avengers))

avengers = ('ironman', 'thor', 'captain', 'hulk', 'thor', 'wanda', 'black widow')
print("type of avengers =", type(avengers))
