
avengers = ('ironman', 'thor', 'captain', ['hulk', 'thor', 'wanda'], 'black widow')

avengers[3] = 'captain marvel'
