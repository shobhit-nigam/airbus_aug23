dataA = 12          #int
dataB = [4, 6, 7]   #list
dataC = (4, 6, 7)   #tuple
dataD = (10 * 20)   #int
dataE = (10)        #int
dataF = (10,)       #tuple
dataG = 10,20,30    #tuple
