print(173/7)
print(173%7)
print(173//7)
print(4**3)
