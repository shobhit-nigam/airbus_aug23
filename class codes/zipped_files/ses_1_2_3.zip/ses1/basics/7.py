x = None

print(x)

print(type(x))
