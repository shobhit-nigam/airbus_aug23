avengers = ["ironman", "captain", "thor", "wanda"]

print("hulk" in avengers)
