avengers = ["ironman", "captain", "thor", "wanda"]

print(type(avengers) is tuple)
print(type(avengers[2]) is str)
