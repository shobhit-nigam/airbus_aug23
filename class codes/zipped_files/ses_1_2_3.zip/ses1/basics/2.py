# int varx = 10;

varx = 10
vary = 34.67
name = "john doe"
