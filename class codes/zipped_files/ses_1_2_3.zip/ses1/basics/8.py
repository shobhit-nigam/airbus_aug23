avengers = ["ironman", "captain", "thor", "wanda"]
print("avengers =", avengers)
del avengers[1:3]
print("avengers =", avengers)
del avengers

# error
print("avengers =", avengers)
