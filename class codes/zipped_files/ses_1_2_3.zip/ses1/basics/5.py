dataG = 10, 33.4, "hello"     #tuple
dataA, dataB, dataC = 10, 33.4, "hello"
dataD = dataE = dataF = 30

#error
dataA, dataB = 10, 33.4, "hello"
