listA = [11, 33, 55, 22, 10, 32]
listB = [31, 7, 32, 44, 19, 20, 5, 28, 61, 20]

def square(a):
    return a**2

print(list(map(square, listA)))
