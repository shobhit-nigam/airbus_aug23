listA = ["11", "33", "55", "22", "tt", "gg"]
tupB = ("hh", "qq", "vv", "ss", "rr", "xx")

objz = zip(listA, tupB)
print(dict(objz))
