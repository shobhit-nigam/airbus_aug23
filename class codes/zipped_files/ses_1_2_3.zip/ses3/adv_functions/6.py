listC = (33, 0, [], "", "hi", None, 66, False, [10, 20])

print(list(filter(None, listC)))
