ga = 100
print("outside ga =", ga)

def funcX():
    ga = 133
    print("in funcX ga =", ga)

funcX()

print("outside ga =", ga)
