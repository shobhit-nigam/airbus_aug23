from colour import blue, green

blue()

print("*"*10)

#no error
green()
