from colour import blue, green

blue()

print("*"*10)

#error
yellow()
