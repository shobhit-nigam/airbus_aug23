import os

contents = os.listdir()

print(contents)
