
for identifiers in dir(__builtins__):
    print(identifiers)
