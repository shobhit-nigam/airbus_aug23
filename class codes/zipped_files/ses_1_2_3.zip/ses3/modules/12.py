import sys

new_path = "/Users/shobhit/Desktop/airbus/ses1/list"

sys.path.append(new_path)

import new_list

print(new_list.avengers)
