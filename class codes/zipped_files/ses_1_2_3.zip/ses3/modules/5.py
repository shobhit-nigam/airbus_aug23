import os
import time

print(os.listdir())
time.sleep(5)
os.system("clear")
