import os

print(os.getcwd())

# sample path (windows)
path = "C:\\noel\\newfolder\\basic"
