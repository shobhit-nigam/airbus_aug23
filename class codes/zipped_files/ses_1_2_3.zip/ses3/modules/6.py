import os

path = "/Users/shobhit/Desktop/airbus/ses3/files"
print(os.path.exists(path))

print(os.path.isfile(path))

#os.environ
