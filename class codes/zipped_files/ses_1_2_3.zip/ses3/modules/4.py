import os

#os.mkdir("sample")

os.rmdir("sample")

os.chdir("..")

os.mkdir("files")
