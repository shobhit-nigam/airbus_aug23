print("__name__ in new_colour =", __name__)

if __name__ == "__main__":
    def blue():
        print("cool blue")
else:
    def blue():
        print("ocean blue")

def yellow():
    print("green")

def green():
    print("green is a mixture of:")
    blue()
    yellow()

red = ["scarlet red", "blood red", "wine red", "some more red"]
