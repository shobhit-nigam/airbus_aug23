import colour

colour.blue()

for val in colour.red:
    print("val =", val)
