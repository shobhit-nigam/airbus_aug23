print("in 18.py __name__ =", __name__)
import new_colour

new_colour.blue()
