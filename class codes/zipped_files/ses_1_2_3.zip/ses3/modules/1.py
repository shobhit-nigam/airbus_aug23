import time

print("hello")
time.sleep(5)
print("hi")
