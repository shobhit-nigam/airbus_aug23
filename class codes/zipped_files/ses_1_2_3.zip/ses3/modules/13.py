import os

varx = 13

for identifiers in dir():
    print(identifiers)
