print("fetching library colour....")

def blue():
    print("cool blue")

def yellow():
    print("green")

def green():
    print("green is a mixture of:")
    blue()
    yellow()

red = ["scarlet red", "blood red", "wine red", "some more red"]
