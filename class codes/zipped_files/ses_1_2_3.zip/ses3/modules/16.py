import colour

for identifiers in dir(colour):
    print(identifiers)
